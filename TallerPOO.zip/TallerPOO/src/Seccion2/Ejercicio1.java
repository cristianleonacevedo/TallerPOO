package Seccion2;

public class Ejercicio1 {
	
	public static void main(String[] args) {
		
		int tempambiente = 45;
		
		if (tempambiente < 100) {
			
			System.out.println("Muy frio");
			
		} else if (tempambiente > 100) {
			
			System.out.println("Muy caliente");
			
		}
		
	}

}
