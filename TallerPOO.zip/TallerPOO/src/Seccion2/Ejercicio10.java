package Seccion2;

public class Ejercicio10 {
	
	public static void main(String[] args) {
		
		int n = 1;
		int n2 = 1;
		int[] listnumeros = new int[20];
		listnumeros[0] = 0;
		listnumeros[1] = n;
		
		for(int i = 2; i < 20; i++) {
			
			listnumeros[i] = listnumeros[i-2] + listnumeros[i-1];
		
			System.out.println(listnumeros[i]);
		}
		
	}

}
