package Seccion3;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		String[] juegos = {"ZZZ", "GI", "MC", "CODM", "JSAB"};
		
		for (String juego : juegos) {
			
			System.out.println(juego);
			
		}
		
	}
	
}
