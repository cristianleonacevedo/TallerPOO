package Seccion3;

import java.util.HashSet;

public class Ejercicio7 {
	
	public static void main(String[] args) {
		
		HashSet<String> plantas = new HashSet<>();
		
		plantas.add("AloeVera");
		plantas.add("Platanera");
		plantas.add("PlantaCarnivora");
		
		System.out.println("El tamaño del HashSet es de: " + plantas.size());
		
	}

}
