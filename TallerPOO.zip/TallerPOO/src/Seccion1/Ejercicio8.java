package Seccion1;

public class Ejercicio8 {

	public void excepcion() {
		
		try {
			
			int num = 15;
			System.out.println(num);
			
		}catch (NumberFormatException si) {
			
			System.out.println("error");
			
		}
		
	}
	
}
