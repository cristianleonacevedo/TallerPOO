package Seccion2;

public class Ejercicio8 {

	public static void main(String[] args) {
		
		int num = 1;
		
		for (int i = 0; i <= 10; i++) {
			
			System.out.println(num + " x " + i + ": " + (num * i));
			
			if (i == 10) {
				
				System.out.println("");
				
				num += 1;
				
				for (int j = 0; j <= 10; j++)
					
					System.out.println(num + " x " + j + ": " + (num * j));
				
			}
			
		}

	}

}
