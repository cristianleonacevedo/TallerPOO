package Seccion3;

import java.util.HashMap;

public class Ejercicio9 {
	
	public static void main(String[] args) {
		
		HashMap<Character, Integer> teclas = new HashMap<>();
		
		teclas.put('W', 1);
		teclas.put('A', 2);
		teclas.put('S', 3);
		teclas.put('D', 4);
		
		for(int i = 0; i < teclas.size(); i++) {
			
			System.out.println(teclas.entrySet());
			
		}
		
	}

}
