package Seccion3;

import java.util.HashMap;

public class Ejercicio8 {

	public static void main(String[] args) {
		
		HashMap<String, Integer> nombres = new HashMap<>();
		
		nombres.put("karol", 16);
		nombres.put("cristian", 16);
		nombres.put("nataly", 18);
		
	}
	
}
