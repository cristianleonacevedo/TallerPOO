package Seccion2;

import java.util.Scanner;

public class Ejercicio3 {
	
	public static void menu( ) {
		
		System.out.println("Menu principal");
		System.out.println("");
		System.out.println("¿Que son mejores?");
		System.out.println("");
		System.out.println("1. Perros");
		System.out.println("2. Gatos");
		
	}
	
	public static void main(String[] args) {
		
		Scanner scann = new Scanner(System.in);
		
		menu();
		int respuesta = scann.nextInt();
		
		switch (respuesta) {
		
			case 1:
				System.out.println("si pero no, osea si pero es que no");
				
			case 2:
				System.out.println("totalmente cierto, los gatos son vida, los gatos proveen, dan y quitan...");
				
			default:
				System.out.println("Solo gaots y perros!");
		
		}
		
	}

}
