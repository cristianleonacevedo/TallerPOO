package Seccion2;

import java.util.Scanner;

public class Ejercicio5 {
	
	public static void main(String[] args) {
		
		Scanner scann = new Scanner(System.in);
		
		int num = 1;
		int suma = 0;
		
		while(num != 0) {
			
			System.out.println("La suma actual es de: " + suma);
			System.out.println("");
			System.out.println("Ingresa el numero para sumar(finaliza con 0): ");
			num = scann.nextInt();

			suma += num;
		
			
		}
		
	}
	
}
