package Seccion1;

public class Ejercicio10 {
	
	int num = 10;
	
	double potencia = Math.pow(num, 3);
	double raiz = Math.sqrt(num);
	
}
