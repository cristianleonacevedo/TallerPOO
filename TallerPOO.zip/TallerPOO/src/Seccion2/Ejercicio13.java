package Seccion2;

import java.util.*;

public class Ejercicio13 {
	
	public static void main(String[] args) {
		
		List<Integer> numeros = new ArrayList<>();
		
		numeros.add(1);
		numeros.add(2);
		numeros.add(1);
		numeros.add(2);
		
		Set <Integer> numerosnodupe = new LinkedHashSet<>(numeros);
		
		System.out.println(numeros);
	}

}
