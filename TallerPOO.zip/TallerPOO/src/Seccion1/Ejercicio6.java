package Seccion1;
import java.util.Scanner;

public class Ejercicio6 {

	Scanner scann = new Scanner(System.in);
	
	int num = scann.nextInt();
	double dinero = scann.nextDouble();
	
}
