package Seccion1;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int num = Ejercicio1._int;
		double pi = Ejercicio1._double;
		
		System.out.println("Variables a utilizar: " + num + "y" + pi);
		
		System.out.println("");
		
		System.out.print("Procesos: ");
		
		System.out.println("Suma(num + pi) = " + (num + pi));
		System.out.println("Resta(num - pi) = " + (num - pi));
		System.out.println("Multiplicacion(num * pi) = " + (num * pi));
		System.out.println("Division(num / pi) = " + (num / pi));
		System.out.println("Modulo(num % 2) = " + (num % 2));
		
	}
	
}
