package Seccion1;

public class Ejercicio13 {
	
	public static void main(String[] args) {
		
		char letra = 'K';
		
		int codigoAscii = (int) letra;
		
	}

}
