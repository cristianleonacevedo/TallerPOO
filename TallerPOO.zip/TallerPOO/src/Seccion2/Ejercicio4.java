package Seccion2;

public class Ejercicio4 {

	public static void main(String[] args) {
		
		double num = 20;
		
		double factorial = 1;
		
		for(int i = 1 ; i != num+1; i++ ) {
			
			factorial = factorial * i;
			
			System.out.println(factorial);
			
		}
		
	}
}
