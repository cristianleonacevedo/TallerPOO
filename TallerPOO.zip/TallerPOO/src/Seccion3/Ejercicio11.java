package Seccion3;

import java.util.ArrayList;

public class Ejercicio11 {

	public static void main(String[] args) {
		
		ArrayList<Integer> numeros = new ArrayList<>();
		
		numeros.add(17);
		numeros.add(16);
		numeros.add(18);
		numeros.add(19);
		
		
		
	}
	
}
