package Seccion3;

import java.util.ArrayList;

public class Ejercicio4 {

	public static void main(String[] args) {
		
		ArrayList<Integer> numeros = new ArrayList<>();
		
		numeros.add(1);
		numeros.add(2);
		numeros.add(3);
		numeros.add(4);
		numeros.add(5);
		
		numeros.remove(0);
		numeros.remove(2);
		
		for(int numero : numeros) {
			
			System.out.println(numero);
			
		}
		
	}
	
}
