package Seccion2;

public class Ejercicio9 {
	
	public static void main(String[] args) {
		
		String[] gatos = {"egipcio", "naranjoso", "siames", "ruso azul", "smoking" };
		
		System.out.println("Razas de gatos: ");
		System.out.println("");
		
		for(String gato : gatos) {
			
			System.out.println(gato);
			
		}
		
	}

}
