package Seccion3;

import java.util.LinkedList;
import java.util.ArrayList;

public class Ejercicio6 {
	
	public static void main(String[] args) {
		
		LinkedList<String> frutas = new LinkedList<>();
		
		frutas.add("fresas");
		frutas.add("naranja");
		frutas.add("Pitaya");
		frutas.add("Ciruela");
		
		ArrayList<String> comidas = new ArrayList<>();
		
		comidas.add("pan");
		comidas.add("fresas");
		comidas.add("carne");
		comidas.add("Pitaya");
		
		
		
		for(String fruta : frutas ) {
			
			for(int i = 0; i < frutas.size(); i++) {
				
				if (fruta == comidas.set(i, fruta)) {
					
					System.out.println("La fruta " + fruta + " tambien esta en el array de comidas");
					
				}
				
			}
			
		}
		
	}

}
