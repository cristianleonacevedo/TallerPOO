package Seccion1;

public class Ejercicio4 {
	
	public static boolean hirviendo(int temp, boolean respuesta) {
		
			
			if (temp < 150) {
				
				System.out.println("El agua no esta hirviendo");
				
				respuesta = true;
				
			} else if (temp > 150 || temp == 150) {
				
				System.out.println("El agua esta hirviendo");
				
				respuesta = false;
				
			}
		
		return !respuesta;
		
		
			
		}

	public static void main(String[] args) {
		
		int temp = 100;
		boolean respuesta = false;
		double precio = 3.99;
		
		hirviendo(temp, respuesta);
		
		if (respuesta != false) {
			
			System.out.println("Puedes hacer el cafe y venderlo por: " + precio);
			
		} if (respuesta == false && temp < 150) {
			
			System.out.println("Espera a que se caliente mas el agua su tempera actual es solo de: " + temp);
			
		}
		
		
		
		

	}
}

