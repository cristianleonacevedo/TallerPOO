package Seccion3;

import java.util.ArrayList;

public class Ejercicio5 {

	public static void main(String[] args) {
		
		ArrayList <String> gatos = new ArrayList <String>();
		gatos.add("siames");
		gatos.add("smoking");
		gatos.add("naranjoso");
		gatos.add("ruso azul");
		gatos.add("egipcio");
		
		gatos.toArray();
		
	}
	
}
