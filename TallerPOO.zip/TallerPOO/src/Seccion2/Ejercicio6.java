package Seccion2;

import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {
		
		Scanner scann = new Scanner(System.in);
		
		final int contraseña = 2903;
		int contraseña2;
		
		do {
			
			System.out.println("Introduce la contraseña");
			contraseña2 = scann.nextInt();
			
			if (contraseña2 != contraseña) {
				
				System.out.println("Contraseña incorrecta vuelve a intentar");
				System.out.println("");
				
			} else if(contraseña2 == contraseña) {
				
				System.out.println("Contraseña correcta");
					
			}
			
		} while (contraseña2 != contraseña);
		
		System.out.println("cat");
		
		scann.close();
		
		
	}
	
}
