package Seccion2;

import java.util.ArrayList;
import java.util.Collections;

public class Ejercicio12 {

	public static void main(String[] args) {
			
			ArrayList <String> gatos = new ArrayList <String>();
			gatos.add("siames");
			gatos.add("smoking");
			gatos.add("naranjoso");
			gatos.add("ruso azul");
			gatos.add("egipcio");
			
			Collections.sort(gatos);
			
			System.out.println(gatos);

	}

}
