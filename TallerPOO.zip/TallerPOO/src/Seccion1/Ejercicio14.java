package Seccion1;

public class Ejercicio14 {
	
	public static void main(String[] args) {
		
		String mensaje = "";
		
		if (mensaje.isEmpty()) {
			
			System.out.print("Esta variable esta vacia");
			
		}else {
			
			System.out.println("Esta variavle si tiene valor");
			
		}
		
	}

}
