package Seccion1;

public class Ejercicio12 {
	
	public static void main(String[] args) {
		
		int edad = 19;
		
		System.out.printf("Hola soy juan, tengo " %d edad);
		
	}
	
}
