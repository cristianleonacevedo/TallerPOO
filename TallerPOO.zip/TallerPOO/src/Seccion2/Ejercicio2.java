package Seccion2;

public class Ejercicio2 {
	
	public static void main(String[] args) {
		
		int edad = 24;
		
		if (edad <= 12) {
			
			System.out.println("Eres un niño");
			
		}else if (edad < 18) {
			
			System.out.println("Eres un adolecente");
			
		}else if (edad < 65) {
			
			System.out.println("Eres un adulto");
			
		}else {
			
			System.out.println("Eres un anciano");
			
		}

		
	}
	

}
