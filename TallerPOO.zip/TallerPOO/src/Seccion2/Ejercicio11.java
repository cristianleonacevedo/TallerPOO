package Seccion2;

import java.util.ArrayList;

public class Ejercicio11 {

	public static void main(String[] args) {

			ArrayList <String> gatos = new ArrayList <String>();
			gatos.add("siames");
			gatos.add("smoking");
			gatos.add("naranjoso");
			gatos.add("ruso azul");
			gatos.add("egipcio");
			
			System.out.println(gatos);
		}
		
}
