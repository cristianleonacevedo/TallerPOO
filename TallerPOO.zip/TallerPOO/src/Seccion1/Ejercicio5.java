package Seccion1;

public class Ejercicio5 {
	/*
	 Lo poco que llevo son los puntos a realizar del taller, los he intentado hacer lo mas completos 
	 que podria, aunque procurando la simplicidad
	 */
	
	//y la buena lectura del codigo

}
