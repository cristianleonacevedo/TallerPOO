package Seccion3;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		int n = 5;
		
		int[] numeros = new int[n];
		
		for(int i = 0; i < n; i++) {
			
			numeros[i] = i;
			
			System.out.println(numeros[i]);
			
		}
		
	}
	
}
