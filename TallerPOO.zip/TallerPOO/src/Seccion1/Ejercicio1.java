package Seccion1;

public class Ejercicio1 {
	
	public static int _int = 10;
	public static String _string = "hola"; 
	public static boolean _boolean = true;
	public static double _double = 3.1416;
	public static char _char = 'C';
	
}
