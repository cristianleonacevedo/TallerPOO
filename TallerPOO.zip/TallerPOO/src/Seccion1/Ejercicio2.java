package Seccion1;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		System.out.println("int= " + Ejercicio1._int);
		System.out.println("String= " + Ejercicio1._string);
		System.out.println("boolean= " + Ejercicio1._boolean);
		System.out.println("double= " + Ejercicio1._double);
		System.out.println("char= " + Ejercicio1._char);
	}

}
