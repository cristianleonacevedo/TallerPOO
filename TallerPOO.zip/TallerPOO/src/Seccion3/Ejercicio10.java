package Seccion3;

public class Ejercicio10 {
	
	public static void main(String[] args) {
	
		
		
	}

}
