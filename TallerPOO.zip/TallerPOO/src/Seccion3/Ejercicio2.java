package Seccion3;

public class Ejercicio2 {
	
	public static void main(String[] args) {

		String[] nombres = {"karol", "rafael", "nataly", "caroline"};
		
		for(int i = 0; i < nombres.length; i++) {
			
			System.out.println(nombres[i]);
			
		}
	}
}
