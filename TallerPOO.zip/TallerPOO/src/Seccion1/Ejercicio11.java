package Seccion1;

public class Ejercicio11 {

	double numeroaleatorio = Math.random() * (10 - 1) + 1;
	
}
