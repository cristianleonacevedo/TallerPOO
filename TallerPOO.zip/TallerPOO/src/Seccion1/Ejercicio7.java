package Seccion1;

public class Ejercicio7 {

	String mensaje = "123";
	
	int nums = Integer.parseInt(mensaje);
	double noc = Double.parseDouble(mensaje);
	
}
