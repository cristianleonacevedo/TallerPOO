package Seccion2;

public class Ejercicio7 {
	
	public static void main(String[] args) {
		
		System.out.println("Si el numero es 3, el bucle terminara antes de las iteraciones limite");
		
		//Break
		
		for (int i = 0; i < 10; i++ ) {
			
			double aleatorio = Math.random() * (10 - 1) + 1; 
			
			System.out.println("Numero generado: " + aleatorio + " en la iteracion: " + i);
			
			
			if (aleatorio > 8) {
				
				break;
				
			}
			
		
				System.out.println("");
				
				for (int j = 0; j < 12; j++) {
					
					double variable = j;
					
					if (variable % 2 == 1) {
						
						continue;
						
				}
					
				System.out.println(variable);
				
			}
			
		}
		
	}

}
