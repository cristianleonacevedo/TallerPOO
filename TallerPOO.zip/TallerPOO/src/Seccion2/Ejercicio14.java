package Seccion2;

import java.util.Arrays;

public class Ejercicio14 {
	
	public static void main(String[] args) {
		
		int[] numeros = {1,2,3,4,5};
		
		Arrays.asList(numeros);
		
		for(int i = 0; i < numeros.length; i++)
		
			System.out.println(numeros[i]);
		
	}

}
